function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="text-green-600 text-4xl font-bold p-6 bg-white rounded-xl shadow-xl">
        ✅ Tailwind סוף סוף פועל כמו שצריך!
      </div>
    </div>
  );
}

export default App;
